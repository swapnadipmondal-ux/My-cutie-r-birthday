# Upasana Birthday ❤️

A romantic interactive birthday webpage for Upasana — 21 September.

## Put it on GitHub Pages
1. Create a new GitHub repository.
2. Upload `index.html`.
3. Go to **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select `main` and `/ (root)`, then Save.
6. GitHub will give you a shareable website link.

The page is already mobile-friendly. No server is required.

## Optional photo
If you want to add her photo later, put it in `assets/upasana.jpg` and I can modify the page to show it in the story.
